"""
Clean and tokenize text

Reference from Prof. Pierre-Hadrien Arnoux
"""

import re
from nltk.corpus import stopwords
from pre_processing.nltk_tokenize import TweetTokenizer

class TextProcessor():
    """
    Clean and tokenize text
    """
    def __init__(self):
        self.regex_url = re.compile(r'https?:\/\/[A-Za-z0-9\/\.\-\#]*')
        self.regex_hashtag = re.compile(r'#\w*')
        self.regex_mention = re.compile(r'@\w*')
        self.regex_twitter_handle = re.compile(r'RT')
        self.regex_numbers = re.compile(r'[0-9]+')
        self.regex_punctutation = re.compile(r'[^\w\s]')
        self.tokenizer = TweetTokenizer(strip_handles=True, reduce_len=True, preserve_case=False)

    def clean_text(self, input_text):
        """
        Clean text
        """
        cleaned_text = re.sub(pattern=self.regex_url, repl='', string=input_text)
        cleaned_text = re.sub(pattern=self.regex_hashtag, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_mention, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_twitter_handle, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_numbers, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_punctutation, repl='', string=cleaned_text)
        cleaned_text = cleaned_text.lower().strip()
        return cleaned_text

    def tokenize_text(self, input_text):
        """
        Tokenize text
        """
        tokens = self.tokenizer.tokenize(input_text)

        return tokens
